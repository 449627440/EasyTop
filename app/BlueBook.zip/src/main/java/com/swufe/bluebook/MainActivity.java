package com.swufe.bluebook;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private Toolbar toolbar;
    private NavigationView navigationview;
    private DrawerLayout drawerlayout;
    private ImageButton imageButton;

    /*创建一个Drawerlayout和Toolbar联动的开关*/
    private ActionBarDrawerToggle drawerToggle;
    private static String CityName="小蓝书札";

    private static String TAG= "MainActivity";

    TextView textView1;

    ArrayList<HashMap<String,Object>> list = new ArrayList<HashMap<String,Object>>();

    private Fragment mFragments[];
    private FragmentManager manager;
    private FragmentTransaction transaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView1=findViewById(R.id.title);
        textView1.setText(CityName);
        toolbar = findViewById(R.id.simple_toolbar);
        toolbar.setTitle("");

        navigationview = findViewById(R.id.navigation_view);
        drawerlayout=findViewById(R.id.drawer_layout);

        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            //设置左上角图标是否可点击
            actionBar.setHomeButtonEnabled(true);
            //左上角加上一个返回图标
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
        drawerToggle = new ActionBarDrawerToggle(MainActivity.this, drawerlayout, toolbar, 0, 0);
        drawerToggle.syncState();
        drawerlayout.setDrawerListener(drawerToggle);
        navigationview.setNavigationItemSelectedListener(this);

        mFragments = new Fragment[2];
        manager = getSupportFragmentManager();

        list=(ArrayList<HashMap<String,Object>>)getIntent().getSerializableExtra("retlist");
        Log.i(TAG, "onCreate: "+list);


        mFragments[0]=manager.findFragmentById(R.id.fragment_cardview);
        mFragments[1]=manager.findFragmentById(R.id.fragment_listview);


        transaction = manager.beginTransaction().hide(mFragments[0]).hide(mFragments[1]);
        transaction.show(mFragments[0]).commit();


        imageButton=findViewById(R.id.switch1);
        imageButton.setOnClickListener(new View.OnClickListener() {

            int count=0;
            @Override
            public void onClick(View v) {

                RotateAnimation animation = new RotateAnimation(0.0f, 360.0f,
                        Animation.RELATIVE_TO_SELF, 0.5f,
                        Animation.RELATIVE_TO_SELF, 0.5f);
                animation.setDuration( 400 );
                imageButton.startAnimation( animation );

                count++;
                Log.i(TAG, "onClick: "+count);
                if(count%2==1){
                    FragmentManager fm = getSupportFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.setCustomAnimations(R.anim.push_left_in,R.anim.push_left_out);
                    ft.hide(fm.findFragmentById(R.id.fragment_cardview));
                    ft.show(fm.findFragmentById(R.id.fragment_listview));
                    ft.addToBackStack(null);
                    ft.commit();
                }else if (count%2==0){
                    FragmentManager fm = getSupportFragmentManager();
                    FragmentTransaction ft = fm.beginTransaction();
                    ft.setCustomAnimations(R.anim.push_up_in,R.anim.push_up_out);
                    ft.hide(fm.findFragmentById(R.id.fragment_listview));
                    ft.show(fm.findFragmentById(R.id.fragment_cardview));
                    ft.addToBackStack(null);
                    ft.commit();
                }
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Pass the event to ActionBarDrawerToggle, if it returns
        // true, then it has handled the app icon touch event
        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        Log.i(TAG, "onOptionsItemSelected: true");
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Intent intent = new Intent();
        int id = item.getItemId();
        String mString = null;
        switch (id) {
            case R.id.item_1:
                mString="小蓝书札";
                intent.setClass(this,Main2Activity.class);
                startActivity(intent);
                break;
            case R.id.item_2:
                mString="小蓝书札";
                intent.setClass(this,ScrollingActivity.class);
                startActivity(intent);
                break;
            case R.id.item_3:
                mString="小蓝书札";
                Toast.makeText(this, "此版块正在开发中", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_4:
                mString="小蓝书札";
                Toast.makeText(this, "此版块正在开发中", Toast.LENGTH_SHORT).show();
                break;
            case R.id.item_5:
                System.exit(0);
                break;
        }
        textView1.setText(mString);
        drawerlayout.closeDrawer(GravityCompat.START);
        return true;
    }

    public void onBackPressed() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        // i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK); //如果是服务里调用，必须加入new task标识
        i.addCategory(Intent.CATEGORY_HOME);
        startActivity(i);
    }

}

