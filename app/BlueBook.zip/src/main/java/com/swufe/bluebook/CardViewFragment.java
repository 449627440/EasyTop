package com.swufe.bluebook;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class CardViewFragment extends Fragment {

    private static String TAG = "CardViewFragment";

    private RecyclerView recyclerView;
    private ImageView imageView;
    private View view;
    private TextView tv1,tv2;
    private ArrayList<HashMap<String,Object>> list;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.cardview_res, container,false);
        recyclerView=view.findViewById(R.id.recycler_View);
        tv1= (TextView) view.findViewById(R.id.tv_bigwords);
        tv2= (TextView) view.findViewById(R.id.tv_smallwords);
        imageView=view.findViewById(R.id.tupian);

        list=(ArrayList<HashMap<String,Object>>) ((AppCompatActivity)getActivity()).getIntent().getSerializableExtra("retlist");
        Log.i(TAG, "onCreateView: "+list);

        LinearLayoutManager m = new LinearLayoutManager(getContext());
        m.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(m);
        recycleViewadapter adapter = new recycleViewadapter(list,getContext());

        recyclerView.setAdapter(adapter);


        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }
}
