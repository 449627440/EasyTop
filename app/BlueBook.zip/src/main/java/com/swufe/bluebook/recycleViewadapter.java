package com.swufe.bluebook;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

public class recycleViewadapter extends RecyclerView.Adapter {
    private ArrayList<HashMap<String,Object>> lists;
    private Context context;
    private static String TAG = "recycleViewadapter";

    public recycleViewadapter(ArrayList<HashMap<String,Object>> lists, Context context) {
        this.lists = lists;
        this.context = context;
    }



    class myholder extends RecyclerView.ViewHolder{

        private TextView tv1,tv2;
        private ImageView imageView;
        private CardView cardView;
        public myholder(View itemView) {
            super(itemView);
            tv1=itemView.findViewById(R.id.tv_bigwords);
            tv2=itemView.findViewById(R.id.tv_smallwords);
            imageView=itemView.findViewById(R.id.tupian);
            cardView=itemView.findViewById(R.id.cardView);
        }

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        myholder holder =new myholder(LayoutInflater.from(parent.getContext()).inflate(R.layout.recycleview_item,parent,false));
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        Log.i(TAG, "onBindViewHolder: "+lists);
        ((myholder)holder).tv1.setText((String)lists.get(position).get("author"));
        ((myholder)holder).tv2.setText((String)lists.get(position).get("abstract"));
        Picasso.with(context).load((String)lists.get(position).get("src")).fit().into(((myholder)holder).imageView);
        ((myholder)holder).cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent config = new Intent();
                config.setClass(context,ScrollingActivity.class);
                config.putExtra("url",(String)lists.get(position).get("link"));
                config.putExtra("book",(String)lists.get(position).get("book"));
                context.startActivity(config);
            }
        });
    }




    @Override
    public int getItemCount() {
        return 40;
    }
}
