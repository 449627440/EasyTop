package com.swufe.bluebook;

import android.app.Activity;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.util.Log;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class LaunchActivity extends Activity implements Runnable{

    private static String TAG = "LaunchActivity";
    Handler handler;
    ArrayList<HashMap<String,Object>> retlist = new ArrayList<HashMap<String,Object>>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);

        Thread t = new Thread(this);
        t.start();

        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if(msg.what==5){
                    ArrayList<HashMap<String,Object>> list1 = (ArrayList<HashMap<String,Object>>)msg.obj;
                    Intent intent = new Intent(LaunchActivity.this,MainActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putParcelableArrayList("retlist",(ArrayList)list1);
                    intent.putExtras(bundle);
                    Log.i(TAG, "handleMessage: "+list1);
                    startActivity(intent);
                }
                super.handleMessage(msg);
                finish();
            }
        };
    }

    @Override
    public void run() {


        Document doc = null;
        try {
            doc = Jsoup.connect("https://book.douban.com/").get();

            Elements tables = doc.getElementsByClass("bd");
            Element table2 = tables.get(1);
            Elements list1 = table2.getElementsByClass("list-col list-col5 list-express slide-item");
            Element[] list=new Element[4];
            Elements[] cover=new Elements[4];
            Elements[] author=new Elements[4];
            Elements[] abstract1=new Elements[4];
            String[][] alink = new String[4][10];
            String[][] asrc = new String[4][10];
            String[][] book = new String[4][10];
            String[][] author1 = new String[4][10];
            String[][] abstract2 = new String[4][10];
            for(int i = 0;i<4;i++){
                list[i]= list1.get(i);
                cover[i] =list[i].getElementsByClass("cover");
                author[i]=list[i].select("div[class=author]");
                abstract1[i] =list[i].select("p[class=abstract]");

                int l=0;
                for(Element link2:abstract1[i]){
                    if (l<author[i].size()){
                        abstract2[i][l]=link2.select("p").text();
                        Log.i(TAG, "run: abstract"+i+" "+l+"="+abstract2[i][l]);
                    }
                    l++;
                }

                int k=0;
                for(Element link1:author[i]){
                    if (k<author[i].size()){
                        author1[i][k]=link1.select("div").text();
                        Log.i(TAG, "run: author"+i+" "+k+"="+author1[i][k]);
                    }
                    k++;
                }


                int j=0;
                for(Element link:cover[i]){
                    if(j<cover[i].size()){
                        alink[i][j] = link.select("a").attr("abs:href");
                        Log.i(TAG, "run: alink"+i+" "+j+"="+alink[i][j]);
                        asrc[i][j] = link.select("img").attr("abs:src");
                        Log.i(TAG, "run: asrc"+i+" "+j+"="+asrc[i][j]);
                        book[i][j] = link.select("a").attr("title");
                        Log.i(TAG, "run: book"+i+" "+j+"="+book[i][j]);
                    }
                    j++;
                }

            }
            for (int i=0;i<4;i++){
                for (int j=0;j<10;j++){
                    HashMap<String,Object> map = new HashMap<String,Object>();
                    map.put("link",alink[i][j]);
                    map.put("src",asrc[i][j]);
                    map.put("book",book[i][j]);
                    map.put("author",author1[i][j]);
                    map.put("abstract",abstract2[i][j]);
                    retlist.add(map);
                }
            }
            Log.i(TAG, "run: "+retlist);
            Message msg = handler.obtainMessage(5);
            msg.obj=retlist;
            handler.sendMessage(msg);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}
